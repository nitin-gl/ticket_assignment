package com.nitin.gl.ticket.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/home")
public class DemoController {
	@GetMapping("/hi")
	public String hi(Model model) {
		model.addAttribute("msg", "Hi Controller");
		model.addAttribute("todayDate", new Date());
		return "hi";
	}
	@GetMapping("/hello")
	public String hello(Model model) {
		model.addAttribute("msg", "Hello Controller");
		model.addAttribute("todayDate", new Date());
		return "hello";
	}

}