package com.nitin.gl.ticket.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nitin.gl.ticket.model.Ticket;
import com.nitin.gl.ticket.service.TicketService;

@Controller
@RequestMapping("/tickets")
public class TicketController {
	@Autowired
	TicketService ticketService;
	@GetMapping("/list")
	public String listTickets(Model model) {
		List<Ticket> tickets = ticketService.findAll();
		model.addAttribute("tickets", tickets);
		return "ticket/list-tickets";
	}
	@GetMapping("/showTicketFormForAdd")
	public String showTicketFormForAdd(Model model) {
		Ticket theTicket = new Ticket();
		model.addAttribute("ticket", theTicket);
		return "ticket/ticket-form";
	}
	@PostMapping("/saveTicket")
	public String saveTicket(Model model, @ModelAttribute("ticket") Ticket ticket) {
		ticketService.saveTicket(ticket);
		return "redirect:/tickets/list";
	}
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		ticketService.deleteById(id);
		return "redirect:/tickets/list";
	}
	@GetMapping("/ticketFormForEdit/{id}")
	public String ticketFormForEdit(Model model, @PathVariable int id) {
		Ticket ticket = ticketService.findById(id);
		model.addAttribute("ticket", ticket);
		return"redirect:/tickets/list";
	}
	@GetMapping("/ticketFormForView/{id}")
	public String ticketFormForView(Model model, @PathVariable int id) {
		Ticket ticket = ticketService.findById(id);
		model.addAttribute("ticket", ticket);
		return"redirect:/tickets/list";
	}

}
