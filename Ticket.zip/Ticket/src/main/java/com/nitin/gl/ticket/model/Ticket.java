package com.nitin.gl.ticket.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String TicketTitle;
	private String Description;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTicketTitle() {
		return TicketTitle;
	}
	public void setTicketTitle(String ticketTitle) {
		TicketTitle = ticketTitle;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Ticket(String ticketTitle, String description) {
		super();
		TicketTitle = ticketTitle;
		Description = description;
	}
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}

}
