package com.nitin.gl.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.nitin.gl.ticket.model.Ticket;

public interface TicketRepository extends JpaRepository<Ticket,Integer>{

}
