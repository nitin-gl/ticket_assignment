package com.nitin.gl.ticket.service;

import java.util.List;


import com.nitin.gl.ticket.model.Ticket;

public interface TicketService {

	public List<Ticket> findAll();

	public Ticket findById(int id);

	public void saveTicket(Ticket theTicket);

	public void deleteById(int id);
}
