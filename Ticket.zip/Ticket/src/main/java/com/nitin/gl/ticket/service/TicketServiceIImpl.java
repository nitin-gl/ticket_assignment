package com.nitin.gl.ticket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nitin.gl.ticket.model.Ticket;
import com.nitin.gl.ticket.repository.TicketRepository;

@Service
public class TicketServiceIImpl implements TicketService {
	@Autowired
	TicketRepository ticketRepository;
	
	
	@Override
	public List<Ticket> findAll() {
		// TODO Auto-generated method stub
		return ticketRepository.findAll();
	}

	@Override
	public Ticket findById(int id) {
		// TODO Auto-generated method stub
		Optional<Ticket> result = ticketRepository.findById(id);
		Ticket theTicket = null;
		if (result.isPresent())
			theTicket = result.get();
		else
			throw new RuntimeException("Given Ticket with the id is not present " + id);
		return theTicket;
	}

	@Override
	public void saveTicket(Ticket theTicket) {
		// TODO Auto-generated method stub
		ticketRepository.save(theTicket);

	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		ticketRepository.deleteById(id);;

	}

}
